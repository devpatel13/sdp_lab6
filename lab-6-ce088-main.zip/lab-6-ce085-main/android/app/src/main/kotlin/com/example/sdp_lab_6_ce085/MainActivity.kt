package com.example.sdp_lab_6_ce085

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
